package com.example.therionlabs_spa.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.therionlabs_spa.data.local.LeadEntity
import com.example.therionlabs_spa.ui.components.ValidatedTextField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeadFormScreen(
    online: Boolean,
    onSave: (LeadEntity) -> Unit,
    onShowList: () -> Unit
) {
    var nombre by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var telefono by remember { mutableStateOf("") }
    var nivel by remember { mutableStateOf("") }
    var curso by remember { mutableStateOf("") }
    var modalidad by remember { mutableStateOf("Online") }
    var canal by remember { mutableStateOf("WhatsApp") }
    var observaciones by remember { mutableStateOf("") }
    var foto by remember { mutableStateOf<Bitmap?>(null) }
    var submitted by remember { mutableStateOf(false) }
    var aviso by remember { mutableStateOf(false) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { foto = it }
    val errorNombre = if (submitted && nombre.trim().length < 3) "Ingresa al menos 3 caracteres." else null
    val errorEmail = if (submitted && !Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$").matches(email)) "Ingresa un correo válido." else null
    val errorTelefono = if (submitted && !Regex("^[0-9]{9,10}$").matches(telefono)) "Ingresa un teléfono de 9 o 10 dígitos." else null

    Scaffold(topBar = {
        TopAppBar(title = { Text("THERIONLABS · Nuevo lead") }, actions = {
            Text(if (online) "● Online" else "● Offline", color = if (online) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, modifier = Modifier.padding(end = 14.dp))
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text("Captura de prospecto", style = MaterialTheme.typography.headlineSmall)
            Text("Completa los datos para registrar una persona interesada.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            AnimatedVisibility(visible = aviso) { Text("Revisa los campos marcados antes de guardar.", color = MaterialTheme.colorScheme.error) }
            ValidatedTextField(nombre, { nombre = it }, "Nombre completo *", error = errorNombre, placeholder = "Ej. Camila González")
            ValidatedTextField(email, { email = it }, "Correo electrónico *", error = errorEmail, keyboardType = KeyboardType.Email, placeholder = "nombre@correo.cl")
            ValidatedTextField(telefono, { telefono = it.filter(Char::isDigit).take(10) }, "Teléfono *", error = errorTelefono, keyboardType = KeyboardType.Phone, placeholder = "912345678")
            DropdownField("Nivel de educación", nivel, listOf("Enseñanza media", "Técnico", "Universitario", "Postgrado")) { nivel = it }
            ValidatedTextField(curso, { curso = it }, "Curso de interés *", placeholder = "Ej. Desarrollo de aplicaciones")
            DropdownField("Modalidad", modalidad, listOf("Online", "Presencial", "Híbrida")) { modalidad = it }
            DropdownField("Canal de contacto", canal, listOf("WhatsApp", "Correo", "Teléfono", "Instagram", "Web")) { canal = it }
            OutlinedTextField(observaciones, { observaciones = it }, label = { Text("Observaciones") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            OutlinedButton(onClick = { cameraLauncher.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.CameraAlt, contentDescription = null); Spacer(Modifier.width(8.dp)); Text(if (foto == null) "Capturar fotografía" else "Volver a tomar fotografía")
            }
            foto?.let { Image(it.asImageBitmap(), contentDescription = "Fotografía capturada", modifier = Modifier.fillMaxWidth().height(180.dp)) }
            Button(onClick = {
                submitted = true
                val valid = nombre.trim().length >= 3 && Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$").matches(email) && Regex("^[0-9]{9,10}$").matches(telefono) && curso.isNotBlank()
                if (valid) {
                    onSave(LeadEntity(nombre = nombre.trim(), email = email.trim(), telefono = telefono, nivelEducacion = nivel, cursoInteres = curso.trim(), modalidad = modalidad, canalContacto = canal, observaciones = observaciones.trim(), estaSincronizado = online))
                    nombre = ""; email = ""; telefono = ""; nivel = ""; curso = ""; observaciones = ""; foto = null; submitted = false; aviso = false
                    onShowList()
                } else aviso = true
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PersonAdd, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Guardar prospecto") }
            OutlinedButton(onClick = onShowList, modifier = Modifier.fillMaxWidth()) { Text("Ver listado de leads") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DropdownField(label: String, selected: String, options: List<String>, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(value = selected, onValueChange = {}, readOnly = true, label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.fillMaxWidth().menuAnchor())
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelected(option); expanded = false }) }
        }
    }
}
