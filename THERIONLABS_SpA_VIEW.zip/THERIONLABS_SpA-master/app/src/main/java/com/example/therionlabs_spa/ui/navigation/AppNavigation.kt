package com.example.therionlabs_spa.ui.navigation

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.therionlabs_spa.data.local.LeadEntity
import com.example.therionlabs_spa.ui.screens.LeadFormScreen
import com.example.therionlabs_spa.ui.screens.LeadListScreen

sealed class Screen(val route: String) {
    data object Form : Screen("form")
    data object List : Screen("list")
}

@Composable
fun AppNavigation(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    val leads = remember { mutableStateListOf<LeadEntity>() }
    var online by remember { mutableStateOf(true) }
    NavHost(navController = navController, startDestination = Screen.Form.route, modifier = modifier) {
        composable(Screen.Form.route) {
            LeadFormScreen(online = online, onSave = { lead -> leads.add(lead.copy(id = (leads.size + 1).toLong())) }, onShowList = { navController.navigate(Screen.List.route) })
        }
        composable(Screen.List.route) {
            LeadListScreen(leads = leads, online = online, onAdd = { navController.navigate(Screen.Form.route) })
        }
    }
}
