package com.example.therionlabs_spa.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.therionlabs_spa.data.local.LeadEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LeadListScreen(leads: List<LeadEntity>, online: Boolean, onAdd: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("THERIONLABS · Leads") }, actions = { Text(if (online) "Online" else "Offline", color = if (online) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, modifier = Modifier.padding(end = 16.dp)) }) }, floatingActionButton = {
        FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, contentDescription = "Nuevo lead") }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Prospectos registrados", style = MaterialTheme.typography.headlineSmall)
            Text("${leads.size} ${if (leads.size == 1) "prospecto" else "prospectos"}", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
            AnimatedVisibility(visible = leads.isEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
                        Text("Todavía no hay leads", style = MaterialTheme.typography.titleMedium)
                        Text("Presiona + para registrar el primer prospecto.")
                    }
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 88.dp)) {
                items(leads.reversed(), key = { if (it.id == 0L) it.hashCode().toLong() else it.id }) { lead ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(lead.nombre, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                AssistChip(onClick = {}, label = { Text(if (lead.estaSincronizado) "Online" else "Offline") }, colors = AssistChipDefaults.assistChipColors(containerColor = if (lead.estaSincronizado) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.errorContainer))
                            }
                            Text(lead.email, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Teléfono: ${lead.telefono}")
                            Text("Interés: ${lead.cursoInteres.ifBlank { "Sin especificar" }} · ${lead.modalidad}")
                            Text("Contacto: ${lead.canalContacto} · ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(lead.fechaCaptura))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
