package com.therionlabs.leadcapture.data.local
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "leads")
data class LeadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val rut: String,
    val nombreCompleto: String,
    val correo: String,
    val colegioOrigen: String,
    val carreraInteres: String,
    val fotoCarnetUri: String? = null,
    val fechaRegistro: Long = System.currentTimeMillis(),
    val sincronizado: Boolean = false
)
