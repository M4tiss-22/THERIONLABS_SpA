package com.therionlabs.leadcapture.util
import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

class CameraManager(private val context: Context) {
    fun crearUriParaFoto(): Uri {
        val directorioFotos = File(context.cacheDir, "carnet_photos")
        if (!directorioFotos.exists()) {
            directorioFotos.mkdirs()
        }
        val archivoTemp = File.createTempFile(
            "carnet_${System.currentTimeMillis()}_",
            ".jpg",
            directorioFotos
        )
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            archivoTemp
        )
    }
}