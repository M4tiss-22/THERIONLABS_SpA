package com.therionlabs.leadcapture.data.local
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LeadDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarLead(lead: LeadEntity): Long

    @Query("SELECT * FROM leads ORDER BY fechaRegistro DESC")
    fun obtenerTodosLosLeads(): Flow<List<LeadEntity>>

    @Query("SELECT COUNT(*) FROM leads")
    fun obtenerTotalLeads(): Flow<Int>

    @Query("SELECT * FROM leads WHERE sincronizado = 0")
    suspend fun obtenerLeadsPendientesSincronizacion(): List<LeadEntity>

    @Query("UPDATE leads SET sincronizado = 1 WHERE id = :id")
    suspend fun marcarComoSincronizado(id: Long)
}
